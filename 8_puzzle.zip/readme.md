# 8_puzzle

8_puzzle is a python script to solve the poular 8 puzzle problem.

## Installation

Clone the github repository and extract all its contents. Ensure to have numpy and python 3 installed


## Usage

To change the puzzle that is being solved go into the 8_puzzle.py file and scroll to the end (249th line) and change the variable maze_1
to solve any particular puzzle of choice

Run the code to see the steps in which the 8 puzzle is solved. 3 text files are generated which help in visualizing the output
The file NodePath.txt has the path which needs to be taken to solve the puzzle. 
The file Nodes.txt has all the nodes that are generated while trying to solve the puzzle
The file NodeInfo has the information of the index of all nodes visited with their corresponding parent's index


## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

